function temp
I = imread('CWArrow.png');
II = imread('CCWArrow.png');
[R,C,O] = size(I);
for i = 1:R
    for j = 1:C
        if ~(I(i,j)==238 )
            I(i,j) = 150;
        end
        if ~(II(i,j) == 238)
            II(i,j) = 150;
        end
    end
end
imwrite(I, 'CWArrow.png');
imwrite(II, 'CCWArrow.png');
