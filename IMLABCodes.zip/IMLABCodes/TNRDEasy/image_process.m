function varargout = image_process(varargin)
% IMAGE_PROCESS MATLAB code for image_process.fig
%      IMAGE_PROCESS, by itself, creates a new IMAGE_PROCESS or raises the existing
%      singleton*.
%
%      H = IMAGE_PROCESS returns the handle to a new IMAGE_PROCESS or the handle to
%      the existing singleton*.
%
%      IMAGE_PROCESS('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in IMAGE_PROCESS.M with the given input arguments.
%
%      IMAGE_PROCESS('Property','Value',...) creates a new IMAGE_PROCESS or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before image_process_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to image_process_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help image_process

% Last Modified by GUIDE v2.5 05-Jun-2017 13:08:20

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @image_process_OpeningFcn, ...
                   'gui_OutputFcn',  @image_process_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT

% ------- Common Fcn for displaying histogram ----------------------
function showHist(hObject, eventdata, handles, Idata)
% display histogram in axes_histogram
axes(handles.axes_histogram);
if numel(size(Idata)) > 2
    imhist(rgb2gray(Idata));
else
    imhist(Idata);
end
% ------------------------------------------------------------------
function showNewHist(hObject, eventdata, handles, Idata)
% display histogram in axes_histogramnew
axes(handles.axes_histogramnew);
if numel(size(Idata)) > 2
    imhist(rgb2gray(Idata));
else
    imhist(Idata);
end
% -----------------------End----------------------------------------

% ------- Common Fcn for displaying image --------------------------
function showImg(hObject, eventdata, handles, Idata)
% display histogram in axes_img
chgIconStr = 'get(handle(f), ''JavaFrame'').setFigureIcon(Icon);';
axes(handles.axes_img);
h = imshow(Idata);
assignin('base', 'IdataOld', Idata);
set(h, 'ButtonDownFcn', ['if strcmp(get(gcf, ''SelectionType''), ''open'')',...
                         'f=figure(''numbertitle'', ''off'', ''name'', ''src-img'');',...
                         'imshow(IdataOld); ', chgIconStr, ' end']);
setappdata(handles.axes_img, 'imgsrc', Idata);
% ------------------------------------------------------------------
function showNewImg(hObject, eventdata, handles, Idata)
% display histogram in axes_imgnew
chgIconStr = 'get(handle(f), ''JavaFrame'').setFigureIcon(Icon);';
axes(handles.axes_imgnew);
h = imshow(Idata);
assignin('base', 'IdataNew', Idata);
set(h, 'ButtonDownFcn', ['if strcmp(get(gcf, ''SelectionType''), ''open'')',...
                         'f=figure(''numbertitle'', ''off'', ''name'', ''processed-img'');',...
                         'imshow(IdataNew); ', chgIconStr, ' end']);
setappdata(handles.axes_imgnew, 'imgsrc_new', Idata);
% -------------------------------------------------------------------
function showImgHist(hObject, eventdata, handles, Idata)
% display both image and histogram
showImg(hObject, eventdata, handles, Idata);
showHist(hObject, eventdata, handles, Idata);
% -------------------------------------------------------------------
function showNewImgHist(hObject, eventdata, handles, Idata)
% display both new image and histogram
showNewImg(hObject, eventdata, handles, Idata);
showNewHist(hObject, eventdata, handles, Idata);
% -----------------------End----------------------------------------

% --- Executes just before image_process is made visible.
function image_process_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to image_process (see VARARGIN)

% Choose default command line output for image_process
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes image_process wait for user response (see UIRESUME)
% uiwait(handles.figure1);
%% disable the 'showHist'
set(handles.showHist, 'enable', 'off');
%% set the cData of toggle Button
set(handles.toggleHistBtn, 'cdata', imread('hideHist.png'));
%% change title and icon of figure1
global Icon;
get(handle(handles.figure1), 'JavaFrame').setFigureIcon(Icon);
set(handles.figure1, 'name', 'IMLAB-ImageProcessing');
%% put image into axes_img and histogram
global GIMAGE;
imgsrc = GIMAGE;
showImgHist(hObject, eventdata, handles, imgsrc);

% --- Outputs from this function are returned to the command line.
function varargout = image_process_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --------------------------------------------------------------------
function select_img_Callback(hObject, eventdata, handles)
% hObject    handle to select_img (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% re-put an image into axes_img
[filename, pathname] = uigetfile({'*.bmp; *.jpg; *.png; *.jpeg', 'image files(*.bmp; *.jpg; *.png; *.jpeg)';...
    '*.*', 'all file(*.*)'}, ...
    'Pick an image');
if isequal(filename, 0) || isequal(pathname, 0)
    return;
end
fpath = [pathname, filename];
imgsrc = imread(fpath);
showImgHist(hObject, eventdata, handles, imgsrc);

% --------------------------------------------------------------------
function save_imgnew_Callback(hObject, eventdata, handles)
% hObject    handle to save_imgnew (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%save axes_imgnew image
imgsrc_new = getappdata(handles.axes_imgnew, 'imgsrc_new');
if isequal(imgsrc_new, [])
    return
end

[filename, pathname] = uiputfile({'*.bmp', 'BMP files';'*.jpg', 'JPG files'},'Name your file');
if isequal(filename, 0) || isequal(pathname, 0)
    return
end
fpath=fullfile(pathname, filename);
imwrite(imgsrc_new, fpath);

% --------------------------------------------------------------------
function save_histogramold_Callback(hObject, eventdata, handles)
% hObject    handle to save_histogramold (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%save axes_histogram image

histogram = getframe(handles.axes_histogram);
if isequal(histogram, [])
    return
end

[filename, pathname] = uiputfile({'*.bmp', 'BMP files';'*.jpg', 'JPG files'},'Name your file');
if isequal(filename, 0) || isequal(pathname, 0)
    return
end
fpath=fullfile(pathname, filename);
imwrite(histogram.cdata, fpath);


% --------------------------------------------------------------------
function save_histogramnew_Callback(hObject, eventdata, handles)
% hObject    handle to save_histogramnew (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%save axes_histogramnew image
histogram_new = getframe(handles.axes_histogramnew);
if isequal(histogram_new, [])
    return
end
[filename, pathname] = uiputfile({'*.bmp', 'BMP files';'*.jpg', 'JPG files'},'Name your file');
if isequal(filename, 0) || isequal(pathname, 0)
    return
end
fpath=fullfile(pathname, filename);
imwrite(histogram_new.cdata, fpath);

% --------------------------------------------------------------------
function equalization_Callback(hObject, eventdata, handles)
% hObject    handle to equalization (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Equalization, and put result into axes_imgnew
imgsrc = getappdata(handles.axes_img, 'imgsrc');
if isequal(imgsrc, [])
    return;
end

if numel(size(imgsrc)) > 2
    imgsrc_teq(:,:,1) = histeq(imgsrc(:,:,1));
    imgsrc_teq(:,:,2) = histeq(imgsrc(:,:,2));
    imgsrc_teq(:,:,3) = histeq(imgsrc(:,:,3));
else
    imgsrc_teq = histeq(imgsrc);
end
showNewImgHist(hObject, eventdata, handles, imgsrc_teq);


% --------------------------------------------------------------------
function salt_pepper_Callback(hObject, eventdata, handles)
% hObject    handle to salt_pepper (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% add pepper noise
imgsrc = getappdata(handles.axes_img, 'imgsrc');
if isequal(imgsrc, [])
    return;
end

imgsrc_noise = imnoise(imgsrc, 'salt & pepper', 0.02);
showNewImgHist(hObject, eventdata, handles, imgsrc_noise);


% --------------------------------------------------------------------
function random_Callback(hObject, eventdata, handles)
% hObject    handle to random (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% add random noise
imgsrc = getappdata(handles.axes_img, 'imgsrc');
if isequal(imgsrc, [])
    return;
end

imgsrc_noise = imnoise(imgsrc, 'speckle', 0.02);
showNewImgHist(hObject, eventdata, handles, imgsrc_noise);


% --------------------------------------------------------------------
function gause_Callback(hObject, eventdata, handles)
% hObject    handle to gause (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% add gaussian noise
imgsrc = getappdata(handles.axes_img, 'imgsrc');
if isequal(imgsrc, [])
    return;
end

imgsrc_noise = imnoise(imgsrc, 'gaussian', 0.02);
showNewImgHist(hObject, eventdata, handles, imgsrc_noise);


% --------------------Common Fcn For Ultra-Mid Filter-----------------
function MedFilter(hObject, eventdata, handles, filterSize)
imgsrc = getappdata(handles.axes_img, 'imgsrc');
if isequal(imgsrc, [])
    return;
end
m = filterSize;
if numel(size(imgsrc)) > 2
    imgsrc_filt(:,:,1) = medfilt2(imgsrc(:,:,1), [m, m]);
    imgsrc_filt(:,:,2) = medfilt2(imgsrc(:,:,2), [m, m]);
    imgsrc_filt(:,:,3) = medfilt2(imgsrc(:,:,3), [m, m]);
else
    imgsrc_filt = medfilt2(imgsrc, [m, m]);
end

showNewImgHist(hObject, eventdata, handles, imgsrc_filt);

% --------------------------------------------------------------------

function Untitled_18_Callback(hObject, eventdata, handles)
% hObject    handle to Untitled_18 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% 3*3 mid filter
MedFilter(hObject, eventdata, handles, 3);

% --------------------------------------------------------------------
function Untitled_19_Callback(hObject, eventdata, handles)
% hObject    handle to Untitled_19 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% 5*5 mid filter
MedFilter(hObject, eventdata, handles, 5);

% --------------------------------------------------------------------
function Untitled_20_Callback(hObject, eventdata, handles)
% hObject    handle to Untitled_20 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% 7*7 mid filter
MedFilter(hObject, eventdata, handles, 7);

% --------------------------------------------------------------------
function Untitled_21_Callback(hObject, eventdata, handles)
% hObject    handle to Untitled_21 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% 9*9 mid filter
MedFilter(hObject, eventdata, handles, 9);


% --------------------Common Fcn For Gaussian Filter------------------
function GaussianFilter(hObject, eventdata, handles, filterSize)
imgsrc = getappdata(handles.axes_img, 'imgsrc');
if isequal(imgsrc, [])
    return;
end
m = filterSize;
sigma = 1.6;
gausFilter = fspecial('gaussian', [m,m], sigma);
if numel(size(imgsrc)) > 2
    imgsrc_filt(:,:,1) = imfilter(imgsrc(:,:,1), gausFilter, 'replicate');
    imgsrc_filt(:,:,2) = imfilter(imgsrc(:,:,2), gausFilter, 'replicate');
    imgsrc_filt(:,:,3) = imfilter(imgsrc(:,:,3), gausFilter, 'replicate');
else
    imgsrc_filt = imfilter(imgsrc, gausFilter, 'replicate');
end

showNewImgHist(hObject, eventdata, handles, imgsrc_filt);

% --------------------------------------------------------------------
function Untitled_14_Callback(hObject, eventdata, handles)
% hObject    handle to Untitled_14 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% 3*3 Gaussian filter
GaussianFilter(hObject, eventdata, handles, 3);

% --------------------------------------------------------------------
function Untitled_15_Callback(hObject, eventdata, handles)
% hObject    handle to Untitled_15 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% 5*5 Gaussian filter
GaussianFilter(hObject, eventdata, handles, 5);

% --------------------------------------------------------------------
function Untitled_16_Callback(hObject, eventdata, handles)
% hObject    handle to Untitled_16 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% 7*7 Gaussian filter
GaussianFilter(hObject, eventdata, handles, 7);

% --------------------------------------------------------------------
function Untitled_17_Callback(hObject, eventdata, handles)
% hObject    handle to Untitled_17 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% 9*9 Gaussian filter
GaussianFilter(hObject, eventdata, handles, 9);


% --------------------Common Fcn For Gaussian Filter-------------------
function AvgFilter(hObject, eventdata, handles, filterSize)
imgsrc = getappdata(handles.axes_img, 'imgsrc');
if isequal(imgsrc, [])
    return;
end
m = filterSize;
avgFilter = fspecial('average', [m, m]);
if numel(size(imgsrc)) > 2
    imgsrc_filt(:,:,1) = imfilter(imgsrc(:,:,1), avgFilter, 'replicate');
    imgsrc_filt(:,:,2) = imfilter(imgsrc(:,:,2), avgFilter, 'replicate');
    imgsrc_filt(:,:,3) = imfilter(imgsrc(:,:,3), avgFilter, 'replicate');
else
    imgsrc_filt= imfilter(imgsrc, avgFilter, 'replicate');
end;

showNewImgHist(hObject, eventdata, handles, imgsrc_filt);

% --------------------------------------------------------------------
function Untitled_10_Callback(hObject, eventdata, handles)
% hObject    handle to Untitled_10 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% 3*3 avg filter
AvgFilter(hObject, eventdata, handles, 3);

% --------------------------------------------------------------------
function Untitled_11_Callback(hObject, eventdata, handles)
% hObject    handle to Untitled_11 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% 5*5 avg filter
AvgFilter(hObject, eventdata, handles, 5);

% --------------------------------------------------------------------
function Untitled_12_Callback(hObject, eventdata, handles)
% hObject    handle to Untitled_12 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% 7*7 avg filter
AvgFilter(hObject, eventdata, handles, 7);

% --------------------------------------------------------------------
function Untitled_13_Callback(hObject, eventdata, handles)
% hObject    handle to Untitled_13 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% 9*9 avg filter
AvgFilter(hObject, eventdata, handles, 9);


% --------------------------------------------------------------------
function exit_Callback(hObject, eventdata, handles)
% hObject    handle to exit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
close();


% --------------------------------------------------------------------
% --------------------Common Fcn For Sharpen--------------------------
function Sharpen(hObject, eventdata, handles, operator, integrated)
imgsrc = getappdata(handles.axes_img, 'imgsrc');
if isequal(imgsrc, [])
    return;
end
Sharper = fspecial(operator);

if numel(size(imgsrc)) > 2
    imgsrc_sharp(:,:,1) = imfilter(imgsrc(:,:,1), Sharper, 'replicate');
    imgsrc_sharp(:,:,2) = imfilter(imgsrc(:,:,2), Sharper, 'replicate');
    imgsrc_sharp(:,:,3) = imfilter(imgsrc(:,:,3), Sharper, 'replicate');
else
    imgsrc_sharp = imfilter(imgsrc, Sharper, 'replicate');
end

showNewImgHist(hObject, eventdata, handles, imgsrc_sharp + imgsrc*integrated);

% --------------------------------------------------------------------
function Untitled_22_Callback(hObject, eventdata, handles)
% hObject    handle to Untitled_22 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% sobel sharper(edged)
Sharpen(hObject, eventdata, handles, 'sobel', 0);

% --------------------------------------------------------------------
function Untitled_23_Callback(hObject, eventdata, handles)
% hObject    handle to Untitled_23 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% sobel sharper(integrated)
Sharpen(hObject, eventdata, handles, 'sobel', 1);


% --------------------------------------------------------------------
function Untitled_24_Callback(hObject, eventdata, handles)
% hObject    handle to Untitled_24 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% prewitt sharper(edged)
Sharpen(hObject, eventdata, handles, 'prewitt', 0);

% --------------------------------------------------------------------
function Untitled_25_Callback(hObject, eventdata, handles)
% hObject    handle to Untitled_25 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% prewitt sharper(integrated)
Sharpen(hObject, eventdata, handles, 'prewitt', 1);


% ----------Common Fcn For Roberts' and Differential Sharpen----------
function RobDifSharpen(hObject, eventdata, handles, style, integrated)
imgsrc = getappdata(handles.axes_img, 'imgsrc');
if isequal(imgsrc, [])
    return;
end
% for RGB-scale image
if numel(size(imgsrc)) > 2
    RobDifSharpen4RGB(hObject, eventdata, handles, style, integrated);
    return;
end

[row, col, dep] = size(imgsrc);
imgsrc_sharp = uint8(zeros(row,col,dep));
for i=1:1:row
    for j=1:1:col
        if isequal(i, row) || isequal(j, col)
            imgsrc_sharp(i,j) = imgsrc(i,j);
        else
            if strcmp(style, 'Robert')
                imgsrc_sharp(i,j) = abs(imgsrc(i+1,j+1)-imgsrc(i,j)) + abs(imgsrc(i+1,j)-imgsrc(i,j+1));
            elseif strcmp(style, 'Differential')
                imgsrc_sharp(i,j) = abs(imgsrc(i+1,j)-imgsrc(i,j)) + abs(imgsrc(i,j+1)-imgsrc(i,j));
            end
        end
    end
end
showNewImgHist(hObject, eventdata, handles, imgsrc_sharp + imgsrc*integrated);


function RobDifSharpen4RGB(hObject, eventdata, handles, style, integrated)
imgsrc = getappdata(handles.axes_img, 'imgsrc');
if isequal(imgsrc, [])
    return;
end
if ~(numel(size(imgsrc)) > 2)
    return;
end
[row, col, dep] = size(imgsrc);
imgsrc_sharp_R = zeros(row,col);
imgsrc_sharp_G = zeros(row,col);
imgsrc_sharp_B = zeros(row,col);
imgsrc_R = imgsrc(:,:,1);
imgsrc_G = imgsrc(:,:,2);
imgsrc_B = imgsrc(:,:,3);

imgsrc_sharp = zeros(row,col,dep);
imgsrc_sharp = uint8(imgsrc_sharp);
for i=1:1:row
    for j=1:1:col
        if isequal(i, row) || isequal(j, col)
            imgsrc_sharp_R(i,j) = imgsrc_R(i,j);
            imgsrc_sharp_G(i,j) = imgsrc_G(i,j);
            imgsrc_sharp_B(i,j) = imgsrc_B(i,j);
        else
            if strcmp(style, 'Robert')
                imgsrc_sharp_R(i,j) = abs(imgsrc_R(i+1,j+1)-imgsrc_R(i,j)) + abs(imgsrc_R(i+1,j)-imgsrc_R(i,j+1));
                imgsrc_sharp_G(i,j) = abs(imgsrc_G(i+1,j+1)-imgsrc_G(i,j)) + abs(imgsrc_G(i+1,j)-imgsrc_G(i,j+1));
                imgsrc_sharp_B(i,j) = abs(imgsrc_B(i+1,j+1)-imgsrc_B(i,j)) + abs(imgsrc_B(i+1,j)-imgsrc_B(i,j+1));
            elseif strcmp(style, 'Differential')
                imgsrc_sharp_R(i,j) = abs(imgsrc_R(i+1,j)-imgsrc_R(i,j)) + abs(imgsrc_R(i,j+1)-imgsrc_R(i,j));
                imgsrc_sharp_G(i,j) = abs(imgsrc_G(i+1,j)-imgsrc_G(i,j)) + abs(imgsrc_G(i,j+1)-imgsrc_G(i,j));
                imgsrc_sharp_B(i,j) = abs(imgsrc_B(i+1,j)-imgsrc_B(i,j)) + abs(imgsrc_B(i,j+1)-imgsrc_B(i,j));
            end
        end
    end
end
imgsrc_sharp(:,:,1) = imgsrc_sharp_R;
imgsrc_sharp(:,:,2) = imgsrc_sharp_G;
imgsrc_sharp(:,:,3) = imgsrc_sharp_B;

showNewImgHist(hObject, eventdata, handles, imgsrc_sharp + imgsrc*integrated);

% --------------------------------------------------------------------
function Untitled_26_Callback(hObject, eventdata, handles)
% hObject    handle to Untitled_26 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Roberts sharpen(edged)
RobDifSharpen(hObject, eventdata, handles, 'Robert', 0);

% --------------------------------------------------------------------
function Untitled_27_Callback(hObject, eventdata, handles)
% hObject    handle to Untitled_27 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Roberts sharpen(integrated)
RobDifSharpen(hObject, eventdata, handles, 'Robert', 1);


% --------------------------------------------------------------------
function Untitled_28_Callback(hObject, eventdata, handles)
% hObject    handle to Untitled_28 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% differenial sharpen(edged)
RobDifSharpen(hObject, eventdata, handles, 'Differential', 0)

% --------------------------------------------------------------------
function Untitled_29_Callback(hObject, eventdata, handles)
% hObject    handle to Untitled_29 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% differenial sharpen(integrated)
RobDifSharpen(hObject, eventdata, handles, 'Differential', 1)


% ------------------Common Fcn For Laplacian Sharpen------------------
function LapSharpen(hObject, eventdata, handles, integrated)
imgsrc = getappdata(handles.axes_img, 'imgsrc');
if isequal(imgsrc, [])
    return;
end
row = size(imgsrc,1);
col = size(imgsrc,2);
imgsrc_sharp_gray = zeros(row,col);
imgsrc_sharp_gray = uint8(imgsrc_sharp_gray);

if numel(size(imgsrc)) > 2
    b = double(rgb2gray(imgsrc)); 
else
    b = double(imgsrc);
end
[M,N] = size(b);

c = zeros(M+2,N+2);
c(1,1) = b(1,1); 
for i = 2:M+1 
    c(i,1)=b(i-1,1); 
    c(i,N+2)=b(i-1,N); 
end
for i = 2:N+1 
    c(1,i)=b(1,i-1); 
    c(M+2,i)=b(M,i-1); 
end
for i = 2:M+1 
    for j = 2:N+1 
         c(i,j) = b(i-1,j-1); 
    end;
end 
for i = 2:M 
      for j = 2:N 
         imgsrc_sharp_gray(i,j)=c(i+1,j)+c(i-1,j)+c(i,j+1)+c(i,j-1)-4*c(i,j); 
      end
end

if ~(numel(size(imgsrc)) > 2)
    imgsrc_new = imgsrc_sharp_gray + imgsrc*integrated;
else
    if integrated
        imgsrc_new = zeros(row,col,3);
        imgsrc_new = uint8(imgsrc_new);
        for i = 1:3
            imgsrc_new(:,:,i) = (imgsrc_sharp_gray + imgsrc(:,:,i));
        end
    else
        imgsrc_new = imgsrc_sharp_gray;
    end
end
showNewImgHist(hObject, eventdata, handles, imgsrc_new);

% --------------------------------------------------------------------

function Untitled_30_Callback(hObject, eventdata, handles)
% hObject    handle to Untitled_30 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Laplacian Sharpen(edged)
LapSharpen(hObject, eventdata, handles, 0);

% --------------------------------------------------------------------
function Untitled_31_Callback(hObject, eventdata, handles)
% hObject    handle to Untitled_31 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Laplacian Sharpen(Integrated)
LapSharpen(hObject, eventdata, handles, 1);

% --------------------------------------------------------------------

% -------------Common Fcn for Simple Dilation and Erosion-------------
function SimpleStylize(hObject, eventdata, handles, style)
imgsrc = getappdata(handles.axes_img, 'imgsrc');
if isequal(imgsrc, [])
    return;
end
if strcmpi(style, 'dilation')
    type = 1;
    mi = 0; ma = 1;
elseif strcmpi(style, 'erosion')
    type = -1;
    mi = 1; ma = 0;
else
    return;
end
H = [1,1,1;1,2,1;1,1,1]*type;
[row, col, dep] = size(imgsrc);
if ~(dep < 3)
    imgsrc_R = imgsrc(:,:,1);
    imgsrc_G = imgsrc(:,:,2);
    imgsrc_B = imgsrc(:,:,3);
    imgsrc_style_R = imgsrc(:,:,1);
    imgsrc_style_G = imgsrc(:,:,2);
    imgsrc_style_B = imgsrc(:,:,3);

    for i=2:row-1
        for j=2:col-1
           imtemp2 = imgsrc_R(i-1:i+1,j-1:j+1);
           imtemp = double(imtemp2) + H;
           imgsrc_style_R(i,j) = mi*min(min(imtemp)) + ma*max(max(imtemp));

           imtemp2 = imgsrc_G(i-1:i+1,j-1:j+1);
           imtemp = double(imtemp2) + H;
           imgsrc_style_G(i,j) = mi*min(min(imtemp)) + ma*max(max(imtemp));

           imtemp2 = imgsrc_B(i-1:i+1,j-1:j+1);
           imtemp = double(imtemp2) + H;
           imgsrc_style_B(i,j) = mi*min(min(imtemp)) + ma*max(max(imtemp));      
        end
    end
    imgsrc_style(:,:,1) = imgsrc_style_R;
    imgsrc_style(:,:,2) = imgsrc_style_G;
    imgsrc_style(:,:,3) = imgsrc_style_B;
else
    imgsrc_style = imgsrc;
    for i=2:row-1
        for j=2:col-1
           imtemp2 = imgsrc(i-1:i+1,j-1:j+1);
           imtemp = double(imtemp2) + H;
           imgsrc_style(i,j) = mi*min(min(imtemp)) + ma*max(max(imtemp));  
        end
    end

end

showNewImgHist(hObject, eventdata, handles, imgsrc_style);

% --------------------------------------------------------------------
function sample_one_Callback(hObject, eventdata, handles)
% hObject    handle to sample_one (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% simple Dilation 3*3
SimpleStylize(hObject, eventdata, handles, 'dilation');

% --------------------------------------------------------------------
function sample_two_Callback(hObject, eventdata, handles)
% hObject    handle to sample_two (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% simple Erosion 3*3
SimpleStylize(hObject, eventdata, handles, 'erosion');

% --------------------------------------------------------------------
function erode_disk_Callback(hObject, eventdata, handles)
% hObject    handle to erode_disk (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% disk Erosion��3��4
imgsrc = getappdata(handles.axes_img, 'imgsrc');
if isequal(imgsrc, [])
    return;
end
SE = strel('disk', 3,4);
imgsrc_style = imerode(imgsrc, SE);
showNewImgHist(hObject, eventdata, handles, imgsrc_style);


% --------------------------------------------------------------------
function erode_diamond_Callback(hObject, eventdata, handles)
% hObject    handle to erode_diamond (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% diamond Erosion��5
imgsrc = getappdata(handles.axes_img, 'imgsrc');
if isequal(imgsrc, [])
    return;
end
SE = strel('diamond', 5);
imgsrc_style = imerode(imgsrc, SE);
showNewImgHist(hObject, eventdata, handles, imgsrc_style);

% --------------------------------------------------------------------
function dilate_disk_Callback(hObject, eventdata, handles)
% hObject    handle to dilate_disk (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% disk Dilation��3��4
imgsrc = getappdata(handles.axes_img, 'imgsrc');
if isequal(imgsrc, [])
    return;
end
SE = strel('disk', 3,4);
imgsrc_style = imdilate(imgsrc, SE);
showNewImgHist(hObject, eventdata, handles, imgsrc_style);

% --------------------------------------------------------------------
function dilate_diamond_Callback(hObject, eventdata, handles)
% hObject    handle to dilate_diamond (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% diamond Dilation��5
imgsrc = getappdata(handles.axes_img, 'imgsrc');
if isequal(imgsrc, [])
    return;
end
SE = strel('diamond', 5);
imgsrc_style = imdilate(imgsrc, SE);
showNewImgHist(hObject, eventdata, handles, imgsrc_style);

% --------------------------------------------------------------------
function erode_line_Callback(hObject, eventdata, handles)
% hObject    handle to erode_line (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% line Erosion��19��0
imgsrc = getappdata(handles.axes_img, 'imgsrc');
if isequal(imgsrc, [])
    return;
end
SE = strel('line', 19,0);
imgsrc_style = imerode(imgsrc, SE);
showNewImgHist(hObject, eventdata, handles, imgsrc_style);


% --------------------------------------------------------------------
function dilate_line_Callback(hObject, eventdata, handles)
% hObject    handle to dilate_line (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% line Delation��19��0
imgsrc = getappdata(handles.axes_img, 'imgsrc');
if isequal(imgsrc, [])
    return;
end
SE = strel('line', 19,0);
imgsrc_style = imdilate(imgsrc, SE);
showNewImgHist(hObject, eventdata, handles, imgsrc_style);


% --------------------------------------------------------------------
function erode_octagon_Callback(hObject, eventdata, handles)
% hObject    handle to erode_octagon (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% octagon Erosion��9��0
imgsrc = getappdata(handles.axes_img, 'imgsrc');
if isequal(imgsrc, [])
    return;
end
SE = strel('octagon', 9);
imgsrc_style = imerode(imgsrc, SE);
showNewImgHist(hObject, eventdata, handles, imgsrc_style);


% --------------------------------------------------------------------
function octagon_dilate_Callback(hObject, eventdata, handles)
% hObject    handle to octagon_dilate (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% octagon Dilation��9
imgsrc = getappdata(handles.axes_img, 'imgsrc');
if isequal(imgsrc, [])
    return;
end
SE = strel('octagon', 9);
imgsrc_style = imdilate(imgsrc, SE);
showNewImgHist(hObject, eventdata, handles, imgsrc_style);


% --------------------------------------------------------------------
function Untitled_33_Callback(hObject, eventdata, handles)
% hObject    handle to Untitled_33 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% line Erosion and Dilation
imgsrc = getappdata(handles.axes_img, 'imgsrc');
if isequal(imgsrc, [])
    return;
end
SE = strel('line', 19, 0);
imgsrc_style = imerode(imgsrc, SE);
imgsrc_style = imdilate(imgsrc_style, SE);

showNewImgHist(hObject, eventdata, handles, imgsrc_style);

% --------------------------------------------------------------------
function find_circles_Callback(hObject, eventdata, handles)
% hObject    handle to find_circles (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% find circles in the image
imgsrc = getappdata(handles.axes_img, 'imgsrc');
if isequal(imgsrc, [])
    return;
end

showNewImg(hObject, eventdata, handles, imgsrc);
[row, col] = size(imgsrc);

steps = ceil(min(row,col)/40);
Rmin = 20;
Rmax = 60;
global Icon;
wbar = waitbar(0, 'Please Wait ...', 'WindowStyle', 'modal', 'CloseRequestFcn', '');
get(handle(wbar), 'JavaFrame').setFigureIcon(Icon);
for i = 1:steps
    [centersBright, radiiBright] = imfindcircles(imgsrc,[Rmin Rmax],'ObjectPolarity','bright');
    [centersDark, radiiDark] = imfindcircles(imgsrc,[Rmin Rmax],'ObjectPolarity','dark');
    viscircles(handles.axes_imgnew, centersBright, radiiBright,'EdgeColor','b');
    viscircles(handles.axes_imgnew, centersDark, radiiDark,'LineStyle','-');
    Rmin = Rmax + 1;
    Rmax = Rmax + 40;
    waitbar(i/steps, wbar);
end
delete(wbar);
showNewHist(hObject, eventdata, handles, imgsrc);

% --------------------------------------------------------------------
function sample_three_Callback(hObject, eventdata, handles)
% hObject    handle to sample_three (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% simple imopen-operation
imgsrc = getappdata(handles.axes_img, 'imgsrc');
if isequal(imgsrc, [])
    return;
end
SE = strel('disk', 3,4);
imgsrc_style = imerode(imgsrc, SE);
imgsrc_style = imdilate(imgsrc_style, SE);

showNewImgHist(hObject, eventdata, handles, imgsrc_style);

% --------------------------------------------------------------------
function sample_four_Callback(hObject, eventdata, handles)
% hObject    handle to sample_four (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% simplr imclose-operation
imgsrc = getappdata(handles.axes_img, 'imgsrc');
if isequal(imgsrc, [])
    return;
end
SE = strel('disk', 3,4);
imgsrc_style = imdilate(imgsrc, SE);
imgsrc_style = imerode(imgsrc_style, SE);
showNewImgHist(hObject, eventdata, handles, imgsrc_style);

% --------------------------------------------------------------------
function opposite_Callback(hObject, eventdata, handles)
% hObject    handle to opposite (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
imgsrc = getappdata(handles.axes_img, 'imgsrc');
if isequal(imgsrc, [])
    return;
end

showNewImgHist(hObject, eventdata, handles, imcomplement(imgsrc));

% --------------------------------------------------------------------
function HCM_divide_Callback(hObject, eventdata, handles)
% hObject    handle to HCM_divide (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% kmeans k=5
imgsrc = getappdata(handles.axes_img, 'imgsrc');
if isequal(imgsrc, [])
    return;
end
k = 5;
global Icon;
wbar = waitbar(1/2, 'Please Wait ...', 'WindowStyle', 'modal', 'CloseRequestFcn', '');
get(handle(wbar), 'JavaFrame').setFigureIcon(Icon);
if numel(size(imgsrc)) > 2
    [muR, maskR, img_div(:,:,1)] = myKmeans(imgsrc(:,:,1), k);
    [muG, maskG, img_div(:,:,2)] = myKmeans(imgsrc(:,:,2), k);
    [muB, maskB, img_div(:,:,3)] = myKmeans(imgsrc(:,:,3), k);
else
    [muR, maskR, img_div] = myKmeans(imgsrc, k);
end
delete(wbar);
showNewImg(hObject, eventdata, handles, img_div);
% show histogram    
axes(handles.axes_histogramnew);
x = 0:255;
if numel(size(img_div)) > 2
    histogram = imhist(img_div(:,:,1));
    plot(x, histogram);
    set(findobj(gca,'Color','b'),'Color', 'r'); hold on;
    
    histogram = imhist(img_div(:,:,2));
    plot(x, histogram);
    set(findobj(gca,'Color','b'),'Color', 'g'); hold on;

    histogram = imhist(img_div(:,:,3));
    plot(x, histogram); hold off;
else
    histogram = imhist(img_div);
    plot(x, histogram);
end

% --------------------------------------------------------------------
function get_gray_Callback(hObject, eventdata, handles)
% hObject    handle to get_gray (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% rgb2gray
imgsrc = getappdata(handles.axes_img, 'imgsrc');
if isequal(imgsrc, [])
    return;
end
if numel(size(imgsrc)) > 2
    imgsrc = rgb2gray(imgsrc);
end
showNewImgHist(hObject, eventdata, handles, imgsrc);


% --------------------------------------------------------------------
function hideHist_Callback(hObject, eventdata, handles)
% hObject    handle to hideHist (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% hide panels of histogram
set(handles.oldHistPanel, 'visible', 'off');
set(handles.newHistPanel, 'visible', 'off');
lbwho = get(handles.oldImgPanel, 'position');
lbwhn = get(handles.newImgPanel, 'position');
set(handles.oldImgPanel, 'position', [lbwho(1)*2, lbwho(2), lbwho(3)*2, lbwho(4)]);
set(handles.newImgPanel, 'position', [lbwhn(1)*2, lbwhn(2), lbwhn(3)*2, lbwhn(4)]);
set(handles.showHist, 'enable', 'on');
set(handles.hideHist, 'enable', 'off');
set(handles.OnlyNewImg, 'enable', 'off');
% change the toggle hist button
lbwht = get(handles.toggleHistBtn, 'position');
set(handles.toggleHistBtn, 'position', [lbwht(1)*2.08, lbwht(2), lbwht(3)*2.0, lbwht(4)*2.0],...
                           'cdata', imread('showHist.png'));

% --------------------------------------------------------------------
function showHist_Callback(hObject, eventdata, handles)
% hObject    handle to showHist (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% show panels of histogram
lbwho = get(handles.oldImgPanel, 'position');
lbwhn = get(handles.newImgPanel, 'position');
set(handles.oldImgPanel, 'position', [lbwho(1)*0.5, lbwho(2), lbwho(3)*0.5, lbwho(4)]);
set(handles.newImgPanel, 'position', [lbwhn(1)*0.5, lbwhn(2), lbwhn(3)*0.5, lbwhn(4)]);
set(handles.oldHistPanel, 'visible', 'on');
set(handles.newHistPanel, 'visible', 'on');
set(handles.showHist, 'enable', 'off');
set(handles.hideHist, 'enable', 'on');
set(handles.OnlyNewImg, 'enable', 'on');
% change the toggle hist button
lbwht = get(handles.toggleHistBtn, 'position');
set(handles.toggleHistBtn, 'position', [lbwht(1)/2.08, lbwht(2), lbwht(3)*0.5, lbwht(4)*0.5],...
                           'cdata', imread('hideHist.png'));

% --------------------------------------------------------------------
function OnlyNewImg_Callback(hObject, eventdata, handles)
% hObject    handle to OnlyNewImg (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% hide histograms and old image
if strcmpi(get(handles.oldHistPanel, 'visible'), 'on')
    set(handles.oldHistPanel, 'visible', 'off');
    set(handles.newHistPanel, 'visible', 'off');
    set(handles.oldImgPanel, 'visible', 'off');
    lbwhn = get(handles.newImgPanel, 'position');
    set(handles.newImgPanel, 'position', [lbwhn(1)*2, lbwhn(2)*2, lbwhn(3)*2, lbwhn(4)*2]);
    set(handles.hideHist, 'enable', 'off');
    set(handles.toggleHistBtn, 'visible', 'off');
end


% --------------------------------------------------------------------
function DefShow_Callback(hObject, eventdata, handles)
% hObject    handle to DefShow (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% show all panels in default mode, use the default data
set(handles.oldImgPanel, 'visible', 'on', 'position', [0.043, 0.52129, 0.40208, 0.4599]);
set(handles.newImgPanel, 'visible', 'on', 'position', [0.043, 0.0255, 0.40208, 0.4617]);
set(handles.oldHistPanel, 'visible', 'on', 'position', [0.4733, 0.5196, 0.4911, 0.4617]);
set(handles.newHistPanel, 'visible', 'on', 'position', [0.4733, 0.0255, 0.4911, 0.4617]);
set(handles.hideHist, 'enable', 'on');
set(handles.showHist, 'enable', 'off');
set(handles.OnlyNewImg, 'enable', 'on');
set(handles.toggleHistBtn, 'visible', 'on',...
                           'position', [0.439169, 0.477, 0.03858, 0.04429],...
                           'cdata', imread('hideHist.png'));

% --- Executes on button press in toggleHistBtn.
function toggleHistBtn_Callback(hObject, eventdata, handles)
% hObject    handle to toggleHistBtn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
if strcmpi(get(handles.oldHistPanel, 'visible'), 'on')
    hideHist_Callback(hObject, eventdata, handles);
else
    showHist_Callback(hObject, eventdata, handles);
end
