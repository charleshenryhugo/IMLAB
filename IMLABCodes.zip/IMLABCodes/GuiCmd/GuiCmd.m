function varargout = GuiCmd(varargin)
% GUICMD MATLAB code for GuiCmd.fig
%      GUICMD, by itself, creates a new GUICMD or raises the existing
%      singleton*.
%
%      H = GUICMD returns the handle to a new GUICMD or the handle to
%      the existing singleton*.
%
%      GUICMD('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in GUICMD.M with the given input arguments.
%
%      GUICMD('Property','Value',...) creates a new GUICMD or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before GuiCmd_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to GuiCmd_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help GuiCmd

% Last Modified by GUIDE v2.5 23-Apr-2017 14:49:25

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @GuiCmd_OpeningFcn, ...
                   'gui_OutputFcn',  @GuiCmd_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before GuiCmd is made visible.
function GuiCmd_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to GuiCmd (see VARARGIN)

% Choose default command line output for GuiCmd
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes GuiCmd wait for user response (see UIRESUME)
% uiwait(handles.cmdFig);
%current path
global CURPATH;
CURPATH = pwd;
%set imgs of 2 btns
set(handles.hRunBtn, 'cData', imread('run.png'));
set(handles.hClrBtn, 'cData', imread('clear.png'));


% --- Outputs from this function are returned to the command line.
function varargout = GuiCmd_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;



function hEdit_Callback(hObject, eventdata, handles)
% hObject    handle to hEdit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of hEdit as text
%        str2double(get(hObject,'String')) returns contents of hEdit as a double


% --- Executes during object creation, after setting all properties.
function hEdit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to hEdit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function hErrEdit_Callback(hObject, eventdata, handles)
% hObject    handle to hErrEdit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of hErrEdit as text
%        str2double(get(hObject,'String')) returns contents of hErrEdit as a double


% --- Executes during object creation, after setting all properties.
function hErrEdit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to hErrEdit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in hClrBtn.
function hClrBtn_Callback(hObject, eventdata, handles)
% hObject    handle to hClrBtn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.hEdit, 'String', '');
set(handles.hErrEdit, 'String', '');

% --- Executes on button press in hRunBtn.
function hRunBtn_Callback(hObject, eventdata, handles)
% hObject    handle to hRunBtn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global CURPATH;
tmpFig = figure('visible', 'off');
str = get(handles.hEdit, 'String');
R = size(str,1);
if exist('dia.txt', 'file')
    delete('dia.txt'); 
end;                                     
for i=1:R 
    try
        diary('dia.txt'); diary on;
        eval(str(i,:)); 
        diary off;
        fid=fopen('dia.txt');
        C=fscanf(fid, '%c');
        fclose(fid);
        set(handles.hErrEdit, 'ForegroundColor','b','String', C);
    catch ex
        diary('dia.txt'); diary off;
        set(handles.hErrEdit,'String',ex.message, 'ForegroundColor', 'r');
    end
end
cd(CURPATH);
delete(tmpFig);

% --- Executes when user attempts to close cmdFig.
function cmdFig_CloseRequestFcn(hObject, eventdata, handles)
% hObject    handle to cmdFig (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global CURPATH;
% Hint: delete(hObject) closes the figure
if exist('dia.txt','file')
    delete('dia.txt');
end;
cd(CURPATH);
delete(hObject);


% --------------------------------------------------------------------
function hmenu_Callback(hObject, eventdata, handles)
% hObject    handle to hmenu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function clear_Callback(hObject, eventdata, handles)
% hObject    handle to clear (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(gco, 'String', '');
