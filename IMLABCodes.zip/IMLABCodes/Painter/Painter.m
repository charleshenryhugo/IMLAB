function varargout = Painter(varargin)
% PAINTER MATLAB code for Painter.fig
%      PAINTER, by itself, creates a new PAINTER or raises the existing
%      singleton*.
%
%      H = PAINTER returns the handle to a new PAINTER or the handle to
%      the existing singleton*.
%
%      PAINTER('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in PAINTER.M with the given input arguments.
%
%      PAINTER('Property','Value',...) creates a new PAINTER or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before Painter_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to Painter_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help Painter

% Last Modified by GUIDE v2.5 07-Jun-2017 12:11:06

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @Painter_OpeningFcn, ...
                   'gui_OutputFcn',  @Painter_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before Painter is made visible.
function Painter_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to Painter (see VARARGIN)

% Choose default command line output for Painter
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes Painter wait for user response (see UIRESUME)
% uiwait(handles.figure1);
%% set the pics on btns
set(handles.PointerBtn, 'cdata', imread('pointer.png'));
set(handles.SaveImg, 'cdata', imread('saveas.png'));
set(handles.PenBtn, 'cdata', imread('pen.png'));
set(handles.EraserBtn, 'cdata', imread('eraser.png'));
set(handles.ColorPickerBtn, 'cdata', imread('colorpicker.png'));
set(handles.ColorBtn, 'cdata', imread('color.png'));

global GIMAGE;              %get GIMAGE from TNRD ui

global penflag;             %if the 'pen' is enabled.1:enabled/0:disabled
global colorpickerflag;     %if the 'colorpicker' is enabled.1:enabled/0:disabled
global eraserflag;          %if the eraaser is enabled;1:enabled/0:disabled

global btdown;              %if mouse btn has been pushed down.
global pencolor;            %pen color. 
global img_src;             %the target image.
global radius;              %radius of the pen;
global radius_eraser;       %radius of the eraser

img_src = im2double(GIMAGE);
btdown = 0;
radius = 3;
radius_eraser = 10;
penflag = 0;
colorpickerflag = 0;
eraserflag = 0;
axes(handles.axes_img);
himg = imshow(img_src);
set(himg, 'ButtonDownFcn',...
    @(hObject,eventdata)Painter('img_src_ButtonDownFcn',hObject,eventdata,guidata(hObject)));
pencolor = [0,0,0];



% --- Outputs from this function are returned to the command line.
function varargout = Painter_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on mouse press over figure background, over a disabled or
% --- inactive control, or over an axes background.
function figure1_WindowButtonDownFcn(hObject, eventdata, handles)
% hObject    handle to figure1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global btdown;
if strcmp(get(gcf, 'SelectionType'), 'normal')
    btdown = 1;
end


% --- Executes on mouse motion over figure - except title and menu.
function figure1_WindowButtonMotionFcn(hObject, eventdata, handles)
% hObject    handle to figure1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global img_src;
global btdown;
global pt;
global penflag;
global eraserflag;
global pencolor;
global radius;
global radius_eraser;
[R,C,O] = size(img_src);
axes(handles.axes_img);
if (btdown == 1) && (penflag == 1)
    pt = get(handles.axes_img, 'CurrentPoint');
    x = pt(1,1);
    y = pt(1,2);
    if (x > radius) && (y > radius) && (x <= C) && (y <= R)
        rx = x - radius;
        ry = y - radius;
        rectangle('Position', [fix(rx), fix(ry), radius, radius],...
                  'Curvature',[1,1],...
                  'EdgeColor', pencolor, 'FaceColor', pencolor);
        img_src = insertShape(img_src, 'FilledCircle', [floor(x), floor(y), radius], 'color', pencolor);
    end
elseif (btdown == 1) && (eraserflag == 1)
    pt = get(handles.axes_img, 'CurrentPoint');
    x = pt(1,1);
    y = pt(1,2);
    if (x > radius_eraser) && (y > radius_eraser) && (x <= C) && (y <= R)
        rx = x - radius_eraser;
        ry = y - radius_eraser;
        rectangle('Position', [fix(rx), fix(ry), radius_eraser, radius_eraser],...
                  'Curvature',[1,1],...
                  'EdgeColor', [1,1,1], 'FaceColor', [1,1,1]);
        img_src = insertShape(img_src, 'FilledCircle', [floor(x), floor(y), radius_eraser], 'color', [1,1,1]);
    end
end


% --- Executes on mouse press over figure background, over a disabled or
% --- inactive control, or over an axes background.
function figure1_WindowButtonUpFcn(hObject, eventdata, handles)
% hObject    handle to figure1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global btdown;
btdown = 0;
%save current img



% --- Executes on button press in ColorBtn.
function ColorBtn_Callback(hObject, eventdata, handles)
% hObject    handle to ColorBtn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
clear_enabled_states(hObject, eventdata, handles);
global pencolor;
pencolor = uisetcolor([0,0,0])
set(handles.ColorDisplayBtn, 'backgroundcolor', pencolor,...
                             'TooltipString', num2str(256*pencolor));

% --- Executes on button press in ColorPickerBtn.
function ColorPickerBtn_Callback(hObject, eventdata, handles)
% hObject    handle to ColorPickerBtn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
clear_enabled_states(hObject, eventdata, handles);
enable_colorpicker(handles);


% --- Executes on button press in PenBtn.
function PenBtn_Callback(hObject, eventdata, handles)
% hObject    handle to PenBtn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
clear_enabled_states(hObject, eventdata, handles);
enable_pen(handles);

% ---- some enable and disable function
function enable_pen(handles)
global penflag;
penflag = 1;
load('pen16x16.mat');
set(handles.figure1, 'Pointer', 'custom',...
                     'PointerShapeCData', pen16x16,...
                     'PointerShapeHotSpot', [16,1]);
    
function disable_pen(handles)
global penflag;
penflag = 0;
set(handles.figure1, 'Pointer', 'arrow');

function enable_colorpicker(handles)
global colorpickerflag;
colorpickerflag = 1;
set(handles.figure1, 'Pointer', 'circle');

function disable_colorpicker(handles)
global colorpickerflag;
colorpickerflag = 0;
set(handles.figure1, 'Pointer', 'arrow');

function enable_eraser(handles)
global eraserflag;
eraserflag = 1;
load('eraser16x16.mat');
set(handles.figure1, 'Pointer', 'custom',...
                     'PointerShapeCData', eraser16x16,...
                     'PointerShapeHotSpot', [8,8]);

function disable_eraser(handles)
global eraserflag;
eraserflag = 0;
set(handles.figure1, 'Pointer', 'arrow');

% --- Executes on button press in ColorPickerDisplayBtn.
function ColorPickerDisplayBtn_Callback(hObject, eventdata, handles)
% hObject    handle to ColorPickerDisplayBtn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global pencolor;
pencolor = get(hObject, 'backgroundcolor');

% --- Executes on mouse press over axes background.
function img_src_ButtonDownFcn(hObject, eventdata, handles)
% hObject    handle to axes_img (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global pencolor;
global pt;
global colorpickerflag;
global img_src;
[R,C,O] = size(img_src);

if (colorpickerflag == 1)
    axes(handles.axes_img);
    pt = get(handles.axes_img, 'CurrentPoint');
    x = floor(pt(1,1));
    y = floor(pt(1,2));
    if (x >= 1) && (y >= 1) && (x <= C) && (y <= R)
        if (numel(size(img_src)) > 2)
            pencolor = [img_src(y,x,1), img_src(y,x,2), img_src(y,x,3)];
        else
            pencolor = [img_src(y,x), img_src(y,x), img_src(y,x)];
        end    
    end
    set(handles.ColorPickerDisplayBtn, 'backgroundcolor', pencolor,...
                                       'TooltipString', num2str(256*pencolor));
end


% --- Executes on button press in ColorDisplayBtn.
function ColorDisplayBtn_Callback(hObject, eventdata, handles)
% hObject    handle to ColorDisplayBtn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global pencolor;
pencolor = get(hObject, 'backgroundcolor');


% --- clear all the enabled states;
function clear_enabled_states(hObject, eventdata, handles)
disable_pen(handles);
disable_colorpicker(handles);
disable_eraser(handles);

% --- Executes on button press in PointerBtn.
function PointerBtn_Callback(hObject, eventdata, handles)
% hObject    handle to PointerBtn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
clear_enabled_states(hObject, eventdata, handles);

% --- Executes on button press in EraserBtn.
function EraserBtn_Callback(hObject, eventdata, handles)
% hObject    handle to EraserBtn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
clear_enabled_states(hObject, eventdata, handles);
enable_eraser(handles);


% --- Executes on slider movement.
function EraserRadiusSlider_Callback(hObject, eventdata, handles)
% hObject    handle to EraserRadiusSlider (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider
global radius_eraser;
radius_eraser = ceil(80 * get(hObject, 'value'));
if(radius_eraser == 0)
    radius_eraser = radius_eraser + 1;
end
set(hObject, 'TooltipString', ['Adjust eraser radius,', num2str(radius_eraser)]);



% --- Executes on slider movement.
function PenRadiusSlider_Callback(hObject, eventdata, handles)
% hObject    handle to PenRadiusSlider (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider
global radius;
radius = ceil(20 * get(hObject, 'value'));
if(radius == 0)
    radius = radius + 1;
end
set(hObject, 'TooltipString', ['Adjust pen radius,', num2str(radius)]);


% --- Executes on button press in SaveImg.
function SaveImg_Callback(hObject, eventdata, handles)
% hObject    handle to SaveImg (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global img_src;
[filename, pathname] = uiputfile({'*.bmp', 'BMP files';'*.jpg', 'JPG files'},'Name your file');
if isequal(filename, 0) || isequal(pathname, 0)
    return
end
fpath=fullfile(pathname, filename);
imwrite(img_src, fpath);


% closeRequestFunction of Painter figure
function closeRequestFcn4Fig(hObject, eventdata, handles)
global img_src;
global GIMAGE;
if img_src - im2double(GIMAGE) == 0
    delete(handles.figure1);
    return;
end

choice = questdlg('Would you like to save the doodled image before exit? ',...
                  'Confirm',...
                  'YES', 'NO', 'NO');
if strcmp(choice, 'YES')   
    [filename, pathname] = uiputfile({'*.bmp', 'BMP files';'*.jpg', 'JPG files'},'Name your file');
    if isequal(filename, 0) || isequal(pathname, 0)
        return
    end
    fpath=fullfile(pathname, filename);
    imwrite(img_src, fpath);
    delete(handles.figure1);
elseif strcmp(choice, 'NO')
    delete(handles.figure1);
end


% --- Executes when user attempts to close figure1.
function figure1_CloseRequestFcn(hObject, eventdata, handles)
% hObject    handle to figure1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: delete(hObject) closes the figure
closeRequestFcn4Fig(hObject, eventdata, handles);
