function varargout = TNRD(varargin)
% TNRD MATLAB code for TNRD.fig
%      TNRD, by itself, creates a new TNRD or raises the existing
%      singleton*.
%
%      H = TNRD returns the handle to a new TNRD or the handle to
%      the existing singleton*.
%
%      TNRD('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in TNRD.M with the given input arguments.
%
%      TNRD('Property','Value',...) creates a new TNRD or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before TNRD_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to TNRD_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help TNRD

% Last Modified by GUIDE v2.5 06-Jun-2017 23:10:24

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @TNRD_OpeningFcn, ...
                   'gui_OutputFcn',  @TNRD_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before TNRD is made visible.
function TNRD_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to TNRD (see VARARGIN)

% Choose default command line output for TNRD
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes TNRD wait for user response (see UIRESUME)
% uiwait(handles.TNRDFig);
set(handles.imCutBtn, 'cData', imread('Arrows\imCut.png'));
set(handles.imDtlsBtn, 'cData', imread('Arrows\imDetails.png'));
set(handles.clrBtn, 'cData', imread('Arrows\clear.png'));
set(handles.GaussianDenoisingBtn, 'cData', imread('Arrows\run.png'));
set(handles.SRBtn, 'cData', imread('Arrows\run.png'));
set(handles.DBBtn, 'cData', imread('Arrows\run.png'));
set(handles.selectImgBtn, 'cData', imread('Arrows\SltImg.png'));
set(handles.DoodleBtn, 'cData', imread('Arrows\Doodle.png'));
set(handles.CameraBtn, 'cData', imread('Arrows\Camera.png'));
% Show arrow in axes_RArrow and axes_LArrow
SetAxesArrow(hObject, eventdata, handles);
% Define the IDX of image showed in axes_img(for GIMAGE_CACHE)
global GIMAGE_IDX; %the image that is ready to be shown in axes_img
global GIMAGE_CUR_IDX; %the image that is currently shown in axes_img
GIMAGE_IDX = 1;
GIMAGE_CUR_IDX = 1;
% Set Icon for TNRDFig 
global Icon;
Icon = javax.swing.ImageIcon('log-trans.png');
assignin('base', 'Icon', Icon);
setIcon(hObject);
% Define some path
global TPATH;
TPATH.GAUSS = 'TestCodes(denoising-deblocking-SR)\GaussianDenoising\';
TPATH.SR = 'TestCodes(denoising-deblocking-SR)\SuperResolution\';
TPATH.DB = 'TestCodes(denoising-deblocking-SR)\JPEGdeblocking\';
TPATH.TNRDEASY = 'TNRDEasy\';


% --- Outputs from this function are returned to the command line.
function varargout = TNRD_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;

% ---------------------------- Show Arrows ------------------------------
function RArrow_Callback(hObject, eventdata, handles)
axes(handles.axes_RArrow);
hr = imshow(imread('Arrows\RArrow_d.png'));
pause(0.05);
hr = imshow(imread('Arrows\RArrow.png'));
set(hr, 'ButtonDownFcn',...
    @(hObject,eventdata)TNRD('RArrow_Callback',hObject,eventdata,guidata(hObject)));
ShowNextImg_Callback(hObject, eventdata, handles);
% ------------------------------
function LArrow_Callback(hObject, eventdata, handles)
axes(handles.axes_LArrow);
hl = imshow(imread('Arrows\LArrow_d.png'));
pause(0.05);
hl = imshow(imread('Arrows\LArrow.png'));
set(hl, 'ButtonDownFcn',...
    @(hObject,eventdata)TNRD('LArrow_Callback',hObject,eventdata,guidata(hObject)));
ShowPreviousImg_Callback(hObject, eventdata, handles);
% ------------------------------
function CWArrow_Callback(hObject, eventdata, handles)
axes(handles.axes_CWArrow);
hcw = imshow(imread('Arrows\CWArrow_d.png'));
pause(0.05);
hcw = imshow(imread('Arrows\CWArrow.png'));
set(hcw, 'ButtonDownFcn',...
    @(hObject,eventdata)TNRD('CWArrow_Callback',hObject,eventdata,guidata(hObject)));
CW90_Callback(hObject, eventdata, handles);
% -----------------------------------------------------------------------
function CCWArrow_Callback(hObject, eventdata, handles)
axes(handles.axes_CCWArrow);
hccw = imshow(imread('Arrows\CCWArrow_d.png'));
pause(0.05);
hccw = imshow(imread('Arrows\CCWArrow.png'));
set(hccw, 'ButtonDownFcn',...
    @(hObject,eventdata)TNRD('CCWArrow_Callback',hObject,eventdata,guidata(hObject)));
CCW90_Callback(hObject, eventdata, handles);
% -----------------------------------------------------------------------


function SetAxesArrow(hObject, eventdata, handles)
% set LArrow and RArrow
LArrow = imread('Arrows\LArrow.png');
RArrow = imread('Arrows\RArrow.png');
axes(handles.axes_LArrow);
hl = imshow(LArrow);
set(hl, 'ButtonDownFcn',...
    @(hObject,eventdata)TNRD('LArrow_Callback',hObject,eventdata,guidata(hObject)));
axes(handles.axes_RArrow);
hr = imshow(RArrow);
set(hr, 'ButtonDownFcn',...
    @(hObject,eventdata)TNRD('RArrow_Callback',hObject,eventdata,guidata(hObject)));

% set CWArrow and CCWArrow
CWArrow = imread('Arrows\CWArrow.png');
CCWArrow = imread('Arrows\CCWArrow.png');
axes(handles.axes_CWArrow);
hcw = imshow(CWArrow);
set(hcw, 'ButtonDownFcn',...
    @(hObject,eventdata)TNRD('CWArrow_Callback',hObject,eventdata,guidata(hObject)));
axes(handles.axes_CCWArrow);
hccw = imshow(CCWArrow);
set(hccw, 'ButtonDownFcn',...
    @(hObject,eventdata)TNRD('CCWArrow_Callback',hObject,eventdata,guidata(hObject)));
% -----------------------------------------------------------------------

% -------------- Show new image in the axes_img -------------------------
function SetAxesImg(handles, IData)
% Define the CACHE of images showed in axes_img
global GIMAGE_CACHE;
global GIMAGE_IDX;
global GIMAGE_CUR_IDX;
GIMAGE_CACHE{GIMAGE_IDX} = IData;
GIMAGE_CUR_IDX = GIMAGE_IDX;
GIMAGE_IDX = GIMAGE_IDX + 1;

global GIMAGE;
GIMAGE = IData;
axes(handles.axes_img);
setappdata(handles.axes_img, 'imgsrc', IData);
h = imshow(IData);
set(h, 'UIContextMenu', handles.axes_slt,...
       'ButtonDownFcn', ['if strcmp(get(gcf, ''SelectionType'') ,''open'') ; ',...
                         ' addpath(''TNRDEasy\''); image_process; end']);
% ----------------------------------------------------------------------
% ---------------------- common fcn to set icon ------------------------
function setIcon(h)
global Icon;
get(handle(h), 'JavaFrame').setFigureIcon(Icon);

% ----------------------------------------------------------------------
% --- Executes on button press in selectImgBtn.
function selectImgBtn_Callback(hObject, eventdata, handles)
% hObject    handle to selectImgBtn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% show image in axes_img
[filename, pathname] = uigetfile({'*.bmp; *.jpg; *.png; *.jpeg', 'image files(*.bmp; *.jpg; *.png; *.jpeg)';...
    '*.*', 'all file(*.*)'}, ...
    'Pick an image');
if isequal(filename, 0) || isequal(pathname, 0)
    return;
end
set(handles.axesTipTxt, 'Visible', 'off');

fpath = [pathname, filename];
global GIMAGE_PATH; %store the fpath
GIMAGE_PATH = fpath;
imgsrc = imread(fpath);
SetAxesImg(handles, imgsrc);


% --- Executes on button press in GaussianDenoisingBtn.
function GaussianDenoisingBtn_Callback(hObject, eventdata, handles)
% hObject    handle to GaussianDenoisingBtn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% get image from axes_img
imgsrc = getappdata(handles.axes_img, 'imgsrc');
if isequal(imgsrc, [])
    return;
end
%get values from denoisePanel
List = get(handles.sigmaMenu, 'string');
Val = get(handles.sigmaMenu, 'value');
sigma = (List{Val});
List = get(handles.filtersizeMenu, 'string');
Val = get(handles.filtersizeMenu, 'value');
filter_size = (List{Val});
List = get(handles.runstageMenu, 'string');
Val = get(handles.runstageMenu, 'value');
run_stage = (List{Val});

global TPATH;
rmpath(TPATH.DB); rmpath(TPATH.SR);
addpath(TPATH.GAUSS);
%model = [path,'JointTraining_7x7_400_180x180_stage=5_sigma=5.mat'];
filter_size_str = strcat(filter_size, 'x', filter_size);

model = strcat('JointTraining_', filter_size_str, '_400_180x180_stage=', run_stage, '_sigma=', sigma, '.mat');
%model = 'JointTraining_7x7_400_180x180_stage=5_sigma=25.mat';
%GaussianDenoising(grayimgsrc, model, 25, 7, 5, 48, 8);
filter_size = str2num(filter_size);
filter_num = filter_size^2 - 1;
bsz = 8;
staged = get(handles.stagedCBox, 'value');%1/0
if get(handles.GRAYSltRBtn, 'value')
    [time, rpt] = GaussianDenoising(imgsrc, model, str2num(sigma), filter_size, str2num(run_stage), filter_num, bsz, staged);
elseif get(handles.RGBSltRBtn, 'value')
    [time, rpt] = GaussianDenoising4RGB(imgsrc, model, str2num(sigma), filter_size, str2num(run_stage), filter_num, bsz, staged);
end

if time + 1 == 0
    time = 0;
    rpt = 'Maybe the image above is not RGB-Scale.';
    set(handles.msgEdit, 'foregroundcolor', 'red');
else
    set(handles.msgEdit, 'foregroundcolor', [39/256,58/256,95/256]);
end
set(handles.runtimeEdit, 'string', [num2str(time), ' s']);
set(handles.msgEdit, 'string', [datestr(now), sprintf('\n'), rpt]);



% --- Executes on button press in clrBtn.
function clrBtn_Callback(hObject, eventdata, handles)
% hObject    handle to clrBtn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.msgEdit, 'string', 'No Messages');
set(handles.msgEdit, 'foregroundcolor', [39/256,58/256,95/256]);
set(handles.runtimeEdit, 'string', '0 s');
set(handles.SRRuntimeEdit, 'string', '0 s');
set(handles.DBRuntimeEdit, 'string', '0 s');


% --- Executes on button press in SRBtn.
function SRBtn_Callback(hObject, eventdata, handles)
% hObject    handle to SRBtn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% get image from axes_img
imgsrc = getappdata(handles.axes_img, 'imgsrc');
if isequal(imgsrc, [])
    return;
end
%get values from SRPanel
List = get(handles.upscaleMenu, 'string');
Val = get(handles.upscaleMenu, 'value');
up_scale = (List{Val});

global TPATH;
rmpath(TPATH.DB); rmpath(TPATH.GAUSS);
addpath(TPATH.SR);

model = strcat('JointTraining_91imgs_7x7_stage=5_s=', up_scale, '-G-Bicubic.mat');
staged = get(handles.SRstagedCBox, 'value');%1/0
if get(handles.SRGRAYSltRBtn, 'value')
    [time, rpt] = SuperResolution(imgsrc, model, str2num(up_scale), staged);
elseif get(handles.SRRGBSltRBtn, 'value')
    [time, rpt] = SuperResolution4RGB(imgsrc, model, str2num(up_scale), staged);
end

if time + 1 == 0
    time = 0;
    rpt = 'Maybe the image above is not RGB-Scale.';
    set(handles.msgEdit, 'foregroundcolor', 'red');
else
    set(handles.msgEdit, 'foregroundcolor', [39/256,58/256,95/256]);
end

set(handles.SRRuntimeEdit, 'string', [num2str(time), ' s']);
set(handles.msgEdit, 'string', [datestr(now), sprintf('\n'), rpt]);


% --- Executes on mouse press over axes background.
function axes_img_ButtonDownFcn(hObject, eventdata, handles)
% hObject    handle to axes_img (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function ImSlt_Callback(hObject, eventdata, handles)
% hObject    handle to ImSlt (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
selectImgBtn_Callback(hObject, eventdata, handles);


% --------------------------------------------------------------------
function SaveMsgSlt_Callback(hObject, eventdata, handles)
% hObject    handle to SaveMsgSlt (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% save messages in MESSAGE-BOX
msg = get(handles.msgEdit, 'string');
[filename, pathname] = uiputfile({'*.txt', 'TXT files'},'Name your file');
if isequal(filename, 0) || isequal(pathname, 0) 
    return; 
end
fpath=fullfile(pathname, filename);
% fid = fopen(fpath, 'wt+');
% fprintf(fid, msg);
% fclose(fid);
dlmwrite(fpath, msg, 'delimiter', '');

% --------------------------------------------------------------------

% --- Executes on button press in DBBtn.
function DBBtn_Callback(hObject, eventdata, handles)
% hObject    handle to DBBtn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% get image from axes_img
imgsrc = getappdata(handles.axes_img, 'imgsrc');
if isequal(imgsrc, [])
    return;
end
%get values from DBPanel
List = get(handles.blocklevelMenu, 'string');
Val = get(handles.blocklevelMenu, 'value');
blocklevel = (List{Val});

global TPATH;
rmpath(TPATH.GAUSS); rmpath(TPATH.SR);
addpath(TPATH.DB);

model = strcat('JointTraining_7x7_400_176X176_stage=4_Q=', blocklevel, '.mat');
staged = get(handles.DBstagedCBox, 'value');%1/0
if get(handles.DBGRAYSltRBtn, 'value')
    [time, rpt] = deblocking(imgsrc, model, str2num(blocklevel), staged);
elseif get(handles.DBRGBSltRBtn, 'value')
    [time, rpt] = deblocking4RGB(imgsrc, model, str2num(blocklevel), staged);
end

if time + 1 == 0
    time = 0;
    rpt = 'Maybe the image above is not RGB-Scale.';
    set(handles.msgEdit, 'foregroundcolor', 'red');
else
    set(handles.msgEdit, 'foregroundcolor', [39/256,58/256,95/256]);
end

set(handles.DBRuntimeEdit, 'string', [num2str(time), ' s']);
set(handles.msgEdit, 'string', [datestr(now), sprintf('\n'), rpt]);


% --------------------------------------------------------------------
function ImInfo_Callback(hObject, eventdata, handles)
% hObject    handle to ImInfo (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% browse image information
if isequal(getappdata(handles.axes_img, 'imgsrc'), [])
    return;
end
global GIMAGE;
global GIMAGE_INFO;
global GIMAGE_PATH;
GIMAGE_INFO = imfinfo(GIMAGE_PATH);
str = sprintf('\n');
info = [
    'Filename: ', GIMAGE_INFO.Filename, str,...
    'FileModeDate: ', GIMAGE_INFO.FileModDate, str...
    'FileSize: ', num2str(GIMAGE_INFO.FileSize), str,... 
    'Format: ', GIMAGE_INFO.Format, str,...
    'Width: ', num2str(size(GIMAGE, 2)), str,...
    'Height: ', num2str(size(GIMAGE, 1)), str,...
    'BitDepth: ', num2str(GIMAGE_INFO.BitDepth), str,...
    'ColorType: ', GIMAGE_INFO.ColorType
    ];

mb = msgbox(info, 'Image-Details', 'custom', GIMAGE, colormap, 'modal');
set(findobj(mb, 'Style', 'pushbutton'), 'String', 'OK');

setIcon(mb);


% ------------------- Define a Common Question Dialog ---------------------
function state = QuestionDialog(type)

if strcmpi(type, 'exec')
    choice = questdlg('Are you sure to crop the image? ',...
        'Confirm',...
        'YES', 'NO', 'NO');
    if strcmp(choice, 'YES')
        state = 1;
    else
        state = 0;
    end
elseif strcmpi(type, 'quit')
        choice = questdlg('Are you sure to give up this cut? ',...
        'Confirm',...
        'Give up', 'Back', 'Back');
    if strcmp(choice, 'Give up')
        state = 1;
    else
        state = 0;
    end
else
    state = 0;
end


% --------------------------------------------------------------------
function AreaCut_Callback(hObject, eventdata, handles)
% hObject    handle to AreaCut (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%% get image from axes_img
imgsrc = getappdata(handles.axes_img, 'imgsrc');
if isequal(imgsrc, [])
    return;
end
assignin('base', 'handles', handles);
assignin('base', 'SetAxesImg', @SetAxesImg);
assignin('base', 'QuestionDialog', @QuestionDialog);

fig = figure('numbertitle', 'off', 'name', 'cut an area', 'WindowStyle', 'modal');
assignin('base', 'fig', fig);
set(fig, 'CloseRequestFcn',...
    ['if QuestionDialog(''quit'') ',...
     'delete(fig);', ' end']);
setIcon(fig);
h = imshow(imgsrc);
assignin('base', 'imgsrc', imgsrc);

%% Choose a part of imgsrc
rct = imrect(gca, [1,1,size(imgsrc, 2)-2, size(imgsrc, 1)-2]); 
assignin('base', 'rct', rct);

%% add uicontextmenu
hcmenu = uicontextmenu;
CutSubMenu = uimenu(hcmenu, 'Label', 'Cut', 'Callback',...
    ['if exist(''rct'', ''var'')'' && isvalid(rct) && QuestionDialog(''exec'') ',...
     '[R,C,O]=size(imgsrc);',...
     'lbwh=getPosition(rct);',...
     'gx=ceil(lbwh(1)); gy=ceil(lbwh(2));gw=ceil(lbwh(3)); gh=ceil(lbwh(4));',...
     'imgsrc = imgsrc(max(gy,1):min(gy+gh,R),max(gx,1):min(gx+gw,C),:);',...
     'SetAxesImg(handles, imgsrc);',...
     'delete(fig);',...
     ' end'] );

set(h, 'UIContextMenu', hcmenu);
set(fig, 'UIContextMenu', hcmenu);


% --------------------------------------------------------------------
function saveas_Callback(hObject, eventdata, handles)
% hObject    handle to saveas (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% save image in the axes_img
imgsrc = getappdata(handles.axes_img, 'imgsrc');
if isequal(imgsrc, [])
    return
end

[filename, pathname] = uiputfile({'*.bmp', 'BMP files';'*.jpg', 'JPG files'},'Name your file');
if isequal(filename, 0) || isequal(pathname, 0)
    return
end
fpath=fullfile(pathname, filename);
imwrite(imgsrc, fpath);


% --------------------------------------------------------------------
function SetFont_Callback(hObject, eventdata, handles)
% hObject    handle to SetFont (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
S.FontName=get(handles.axesTipTxt, 'FontName');%'MS Sans Serif';
S.FontWeight=get(handles.axesTipTxt, 'FontWeight');
S.FontAngle=get(handles.axesTipTxt, 'FontAngle');
S.FontUnits=get(handles.axesTipTxt, 'FontUnits');
S.FontSize=get(handles.axesTipTxt, 'FontSize');

hcell = struct2cell(handles);
len = length(hcell);
font = uisetfont(S, 'Select Font');
if ~isa(font, 'struct') && font == 0
    font = S;
end
for i=1:len
    if (hcell{i} - handles.msgEdit) == 0
        continue;
    end
    if isprop(hcell{i}, 'FontName')
        set(hcell{i}, font);
    end
end

% ---------------common fcn for setting color-------------------------
function SetColorHelp(hObject, eventdata, handles, type)
hcell = struct2cell(handles);
len = length(hcell);
c = uisetcolor([0,0,0]);
if c == 0
    c = [0, 0, 0];
end
if strcmpi(type, 'foregroundcolor') || strcmpi(type, 'backgroundcolor')
    for i=1:len
        if (hcell{i} - handles.msgEdit) == 0
            continue;
        end
        if isprop(hcell{i}, type);
            set(hcell{i}, type, [c(1), c(2), c(3)]);
        end
    end
end

% --------------------------------------------------------------------
function SetFore_Callback(hObject, eventdata, handles)
% hObject    handle to SetFore (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
SetColorHelp(hObject, eventdata, handles, 'ForegroundColor');

% --------------------------------------------------------------------
function SetBack_Callback(hObject, eventdata, handles)
% hObject    handle to SetBack (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% SetColorHelp(hObject, eventdata, handles, 'BackgroundColor');

% --------------------------------------------------------------------

% --------------------------------------------------------------------
function SetDefault_Callback(hObject, eventdata, handles)
% hObject    handle to SetDefault (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
S.FontName='MS Sans Serif';
S.FontWeight='normal';
S.FontAngle='normal';
S.FontUnits='points';
S.FontSize=8;
hcell = struct2cell(handles);
len = length(hcell);
for i=1:len
    if (hcell{i} - handles.msgEdit) == 0
        continue;
    end    
    if isprop(hcell{i}, 'ForegroundColor');
        set(hcell{i}, 'ForegroundColor', [0, 0, 0]);
    end
    if isprop(hcell{i}, 'FontName');
        set(hcell{i}, S);
    end
end
set(handles.runtimeTxt, 'ForegroundColor', [39, 58, 95]/256);
set(handles.SRRuntimeTxt, 'ForegroundColor', [39, 58, 95]/256);
set(handles.DBRuntimeTxt, 'ForegroundColor', [39, 58, 95]/256);
set(handles.runtimeEdit, 'ForegroundColor', [39, 58, 95]/256);
set(handles.SRRuntimeEdit, 'ForegroundColor', [39, 58, 95]/256);
set(handles.DBRuntimeEdit, 'ForegroundColor', [39, 58, 95]/256);
set(handles.axesTipTxt, 'FontSize', 10.0);
set(handles.denoisePanel, 'FontWeight', 'bold');
set(handles.SRPanel, 'FontWeight', 'bold');
set(handles.JPEGDeblockPanel, 'FontWeight', 'bold');

% --------------------------------------------------------------------
function PageSetup_Callback(hObject, eventdata, handles)
% hObject    handle to PageSetup (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
dlg = printpreview(handles.TNRDFig);
setIcon(dlg);


% --------------------------------------------------------------------
function Enlarge_Callback(hObject, eventdata, handles)
% hObject    handle to Enlarge (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
imgsrc = getappdata(handles.axes_img, 'imgsrc');
if isequal(imgsrc, [])
    return;
end
f = figure('numbertitle', 'off', 'name', 'src-img');
setIcon(f);
imshow(imgsrc);


% --------------------------------------------------------------------

% - Common fcn to get and show image from GIMAGE_CACHE with given IDX -
function img = getCacheImg(index)
global GIMAGE_CACHE;
img = GIMAGE_CACHE{index};

function showCacheImg(handles, index)
global GIMAGE;
imgsrc = getCacheImg(index);
GIMAGE = imgsrc;
axes(handles.axes_img);
setappdata(handles.axes_img, 'imgsrc', imgsrc);
h = imshow(imgsrc);
set(h, 'UIContextMenu', handles.axes_slt,...
       'ButtonDownFcn', ['if strcmp(get(gcf, ''SelectionType'') ,''open'') ; ',...
                         ' addpath(''TNRDEasy\''); image_process; end']);
% --------------------------------------------------------------------
function ShowPreviousImg_Callback(hObject, eventdata, handles)
% hObject    handle to ShowPreviousImg (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Show previous image in axes_img(get data from GIMAGE_CACHE)
global GIMAGE_CUR_IDX;
if(GIMAGE_CUR_IDX <= 1)
    return;
end

GIMAGE_CUR_IDX = GIMAGE_CUR_IDX - 1;
showCacheImg(handles, GIMAGE_CUR_IDX);


% --------------------------------------------------------------------
function ShowNextImg_Callback(hObject, eventdata, handles)
% hObject    handle to ShowNextImg (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Show next image in axes_img(get data from GIMAGE_CACHE)
global GIMAGE_CUR_IDX;
global GIMAGE_IDX;

if(GIMAGE_CUR_IDX + 1 >= GIMAGE_IDX)
    return;
end

GIMAGE_CUR_IDX = GIMAGE_CUR_IDX + 1;
showCacheImg(handles, GIMAGE_CUR_IDX);


% --------------------------------------------------------------------
function CMD_Callback(hObject, eventdata, handles)
% hObject    handle to CMD (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
addpath('GuiCmd\');
cmdFig = GuiCmd;
setIcon(cmdFig);


% --------------------------------------------------------------------
function RotateImg(hObject, eventdata, handles, angle)
% hObject    handle to Rotate (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
imgsrc = getappdata(handles.axes_img, 'imgsrc');
if isequal(imgsrc, [])
    return;
end

if ~(angle == 90 || angle == -90)
    angle = 90;
end
imgsrc = imrotate(imgsrc, angle);
SetAxesImg(handles, imgsrc);

% --------------------------------------------------------------------
function CW90_Callback(hObject, eventdata, handles)
% hObject    handle to CW90 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% rotate clockwise 90'
RotateImg(hObject, eventdata, handles, -90)

% --------------------------------------------------------------------
function CCW90_Callback(hObject, eventdata, handles)
% hObject    handle to CCW90 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% rotate Anti-clockwise 90'
RotateImg(hObject, eventdata, handles, 90)


% --------------------------------------------------------------------
% --------------------------------------------------------------------
function About_Callback(hObject, eventdata, handles)
% hObject    handle to About (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Show Logo
dlg = dialog('name', 'about  IMLAB');
setIcon(dlg);
logo = imread('logo.png');
imshow(logo,'border','tight');%,'initialmagnification','fit'


% --- Executes on button press in imCutBtn.
function imCutBtn_Callback(hObject, eventdata, handles)
% hObject    handle to imCutBtn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
AreaCut_Callback(hObject, eventdata, handles);


% --- Executes on button press in imDtlsBtn.
function imDtlsBtn_Callback(hObject, eventdata, handles)
% hObject    handle to imDtlsBtn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
ImInfo_Callback(hObject, eventdata, handles);


% --------------------------------------------------------------------
function Camera_Callback(hObject, eventdata, handles)
% hObject    handle to Camera (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
addpath('Camera\');
cameraFig = Camera;
setIcon(cameraFig);


% --------------------------------------------------------------------
function EasyMode_Callback(hObject, eventdata, handles)
% hObject    handle to EasyMode (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
if isequal(getappdata(handles.axes_img, 'imgsrc'), [])
    return;
end
addpath('TNRDEasy\'); 
image_process_fig = image_process;
setIcon(image_process_fig);


% --- Executes on button press in DoodleBtn.
function DoodleBtn_Callback(hObject, eventdata, handles)
% hObject    handle to DoodleBtn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
if isequal(getappdata(handles.axes_img, 'imgsrc'), [])
    return;
end
addpath('Painter\');
PainterFig = Painter;
setIcon(PainterFig);


% --- Executes on button press in CameraBtn.
function CameraBtn_Callback(hObject, eventdata, handles)
% hObject    handle to CameraBtn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
Camera_Callback(hObject, eventdata, handles);
